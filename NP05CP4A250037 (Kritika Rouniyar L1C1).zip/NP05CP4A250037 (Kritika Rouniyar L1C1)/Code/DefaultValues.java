
/**
 * Write a description of class DefaultValues here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DefaultValues
{

        boolean b;
        byte by;
        short s;
        int i;
        long l;
        float f;
        double d;
        char c;
        
        public static void main(String[] args)
        {
        DefaultValues obj = new DefaultValues();//creating oj of the class
        System.out.println("Value of int "+obj.i);
        System.out.println("Value of byte "+obj.by);
        System.out.println("Value of boolen "+obj.b);
        System.out.println("Value of short "+obj.s);
        System.out.println("Value of long "+obj.l);
        System.out.println("Value of float "+obj.f);
        System.out.println("Value of double "+obj.d);
        System.out.println("Value of char "+obj.c);
        
        //

    }
}