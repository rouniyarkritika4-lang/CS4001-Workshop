
/**
 * Write a description of class RickshawFare here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;

public class RickshawFare {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("--- Biratnagar Rickshaw Fare Calculator ---");
        
        // taking inputs
        System.out.println("Distance travelled (km): ");
        double distance= sc.nextDouble();

        System.out.println("Time taken (minutes): ");
        double time = sc.nextDouble();

        System.out.println("Are you a local? (yes/no): ");
        String local = sc.next();

        System.out.println("Is it night time? (yes/no): ");
        String night = sc.next();

        // basic rates
        double baseFare = 50;            // base fare in Rs
        double perKm = 20;               // per kilometer charge
        double perMin = 2;               //per minute charge
        double localDiscountRate=0.10;  // 10% discount if local and distance >= 10 km
        double nightSurchargeRate=0.20; //// 20% extra if traveling at night
        
        double fare = baseFare + (distance * perKm) + (time * perMin);
        //For local discount 
        double discount = fare-0.10;
        fare = (local.equals("yes") && distance>10)? discount : fare;
        //for night surcharge
        double nightSurcharge = fare+0.20;
        fare = (night.equals("yes"))? nightSurcharge : fare;
        
         // Display the final fare clearly
        System.out.println("\n---Fare Summary ---");
        System.out.println("Distance Travelled: " + distance + " km");
        System.out.println("Time Taken: " + time + " minutes");
        System.out.println("Local Customer: " + (local.equals("yes") ? "Yes" : "No"));
        System.out.println("Night Travel: " + (night.equals("yes") ? "Yes" : "No"));
        System.out.println("Final Fare: "+ Math.round(fare));

        sc.close();
    }
}
       
        
        
        
        
