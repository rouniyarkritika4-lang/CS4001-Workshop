
/**
 * Write a description of class DataTypeInspector here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DataTypeInspector
{
    public static void main(String[] args)
    {
        boolean b=true;
        byte by=40;
        short s=40;
        int i= 30;
        long l=30L;
        float f=20.8f;
        double d=30.8d;
        char c='A';
        
        System.out.println("The values boolean is: "+b);
        System.out.println("The values byte is: "+by);
        System.out.println("The values short is: "+s);
        System.out.println("The values int is: "+i);
        System.out.println("The values long is: "+l);
        System.out.println("The values float is: "+f);
        System.out.println("The values double is: "+d);
        System.out.println("The values char is: "+c);
    }
}