
/**
 * Write a description of class LiteralPratice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LiteralPratice
{
    public static void main(String[] args)
    {
        // long literal with L 
        long bigNumber = 500000L;
        // float literal with f
        float price = 9.99f; 
        // Unicode for ©
        char symbol = '\u00A9';          

        System.out.println(bigNumber);
        System.out.println(price);
        System.out.println(symbol);
    }
}