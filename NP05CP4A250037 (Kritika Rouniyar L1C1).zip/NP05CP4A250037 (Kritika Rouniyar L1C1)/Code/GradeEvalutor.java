import java.util.Scanner;
public class GradeEvalutor
{
    public static void main(String[] args){
        Scanner sc= new Scanner (System.in);//creating the scanner class object
        
        System.out.println("Enter the grade");
        double grade=sc.nextDouble();
        
        String result=(grade>=40)? "Pass" : "Fail";
        System.out.println(result);
    }
        
}
        
